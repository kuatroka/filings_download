.. _whatsnew:

**********
What's New
**********

New features, bug fixes, and improvements for each release.

.. include:: whatsnew/v0.4.0.rst

.. include:: whatsnew/v0.3.4.rst

.. include:: whatsnew/v0.3.3.rst

.. include:: whatsnew/v0.3.2.rst

.. include:: whatsnew/v0.3.1.rst

.. include:: whatsnew/v0.3.0.rst

.. include:: whatsnew/v0.2.3.rst

.. include:: whatsnew/v0.2.2.rst

.. include:: whatsnew/v0.2.1.rst

.. include:: whatsnew/v0.2.0.rst

.. include:: whatsnew/v0.1.7.rst

.. include:: whatsnew/v0.1.6.rst

.. include:: whatsnew/v0.1.5.rst

.. include:: whatsnew/v0.1.4.rst

.. include:: whatsnew/v0.1.3.rst

.. include:: whatsnew/v0.1.2.rst

.. include:: whatsnew/v0.1.1.rst
