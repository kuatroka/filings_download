Welcome to secedgar's documentation!
====================================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

.. _getting_started:

.. toctree::
   :maxdepth: 2
   :caption: Getting Started

   install
   usage
   ciklookup
   filings
   filingtypes
   cikmap
   parser
   cli
   whatsnew

.. _package_info:

.. toctree::
   :maxdepth: 3
   :caption: Package Information

   about